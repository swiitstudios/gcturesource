-- Run this ONCE in Supabase > SQL Editor

-- 1. Add a faculty column
alter table departments add column if not exists faculty text;

-- 2. Rename the 4 existing departments (keeps all existing uploads linked)
update departments set name = 'Information Technology',
  faculty = 'Faculty of Computing & Information Systems' where name = 'IT';
update departments set name = 'Computer Science (Cyber Security Option)',
  faculty = 'Faculty of Computing & Information Systems' where name = 'Cyber Security';
update departments set faculty = 'Faculty of Computing & Information Systems'
  where name in ('Software Engineering', 'Computer Science');

-- 3. Add the remaining programmes
insert into departments (name, faculty)
select v.name, v.faculty
from (values
  ('Mobile Computing',                      'Faculty of Computing & Information Systems'),
  ('Information Systems',                   'Faculty of Computing & Information Systems'),
  ('Data Science and Analytics',            'Faculty of Computing & Information Systems'),
  ('Networking and Systems Administration', 'Faculty of Computing & Information Systems'),
  ('Internet of Things and Big Data',       'Faculty of Computing & Information Systems'),

  ('Telecommunication Engineering',         'Faculty of Engineering'),
  ('Computer Engineering',                  'Faculty of Engineering'),
  ('Electrical and Electronics Engineering','Faculty of Engineering'),
  ('Mathematics',                           'Faculty of Engineering'),
  ('Actuarial Science with Data Analytics', 'Faculty of Engineering'),
  ('Computational Statistics',              'Faculty of Engineering'),

  ('Accounting with Computing',             'GCTU Business School'),
  ('Economics',                             'GCTU Business School'),
  ('Procurement and Logistics',             'GCTU Business School'),
  ('E-Commerce and Marketing Management',   'GCTU Business School'),
  ('Financial Technology',                  'GCTU Business School'),
  ('Banking and Finance',                   'GCTU Business School'),
  ('Business Administration',               'GCTU Business School')
) as v(name, faculty)
where not exists (select 1 from departments d where d.name = v.name);

-- 4. Check: should list 22 programmes
select faculty, name from departments order by faculty, name;
